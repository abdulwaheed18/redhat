#!/bin/sh

#################################################################################################
# The script is used to start(on the port we specify)/stop tomcat.								#
#																								#	
# To Start : 																					#
#       ./deploy.sh start <port>   - If we dont specify the port then by default it uses 8443	#
# To Stop																						#
#	./deploy.sh stop																			#	
#################################################################################################

if [ "$1" == "start" ] #If start command received
then
	echo "Starting server"
   	if [  -n "$2" ] #If port is specified with start command
	then
        	if echo $2 | egrep -q '^[0-9]+$'  # Checking if the port entered is numeric
		then
			if [[ "$2" -ge 1  && $2 -le 65535 ]] # Checking if the port entered in within valid range
			then
				export VCAP_APP_PORT=$2 #Setting port value entered by user in environment variable.
			else
				echo "Invalid port number entered. Value should be between 1 & 65535"			
			fi
		else
			echo "Starting with default port as invalid port entered"
		fi
	fi
		apache-tomcat-7.0.34/bin/startup.sh &
elif [ "$1" == "stop" ] #If stop command received
then
	apache-tomcat-7.0.34/bin/shutdown.sh
else
	echo "Invalid or no option entered. Please enter any one of the following
		To Start Tomcat : 
			./deploy.sh start <port>   - If we dont specify the port then by default it uses 8443
		To Stop Tomcat : 
			./deploy.sh stop
	"
fi
